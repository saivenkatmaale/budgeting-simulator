let budgetChart = null; // Store chart instance

document.getElementById('budget-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent page reload
    
    const incomeInput = document.getElementById('income');
    const expensesInput = document.getElementById('expenses');
    const income = parseFloat(incomeInput.value);
    const expenses = parseFloat(expensesInput.value);
    
    if (isNaN(income) || isNaN(expenses) || income <= 0 || expenses < 0) {
        incomeInput.setCustomValidity('Invalid');
        expensesInput.setCustomValidity('Invalid');
        alert('Please enter valid positive numbers for income and expenses.');
        return;
    } else {
        incomeInput.setCustomValidity('');
        expensesInput.setCustomValidity('');
    }
    
    const savings = income - expenses;
    const savingsPercentage = ((savings / income) * 100).toFixed(2);
    
    document.getElementById('savings').textContent = `Savings: $${savings.toFixed(2)}`;
    document.getElementById('percentage').textContent = `Savings Percentage: ${savingsPercentage}%`;
    
    const tipsDiv = document.getElementById('tips');
    tipsDiv.innerHTML = '';
    
    if (savings < 0) {
        tipsDiv.innerHTML += '<p>Tip: Your expenses exceed income! Consider cutting costs. Inflation can make things worse—prices rise over time, so save early.</p>';
    } else if (savingsPercentage < 20) {
        tipsDiv.innerHTML += '<p>Tip: Aim for 20% savings. Loans have interest—borrow wisely to avoid debt traps.</p>';
    } else {
        tipsDiv.innerHTML += '<p>Tip: Great job! Invest savings wisely. Understand taxes: They fund public services but reduce take-home pay.</p>';
    }
    
    document.getElementById('result').style.display = 'block';
    
    const ctx = document.getElementById('budgetChart').getContext('2d');
    if (budgetChart) {
        budgetChart.data.datasets[0].data = [expenses, Math.max(0, savings)];
        budgetChart.update();
    } else {
        budgetChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Expenses', 'Savings'],
                datasets: [{ data: [expenses, Math.max(0, savings)], backgroundColor: ['#FF6384', '#36A2EB'] }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' },
                    title: { display: true, text: 'Budget Breakdown' }
                }
            }
        });
    }
});